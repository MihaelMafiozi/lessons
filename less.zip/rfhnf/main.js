let number = document.getElementById("number")
let name = document.getElementById("name")
let date = document.getElementById("data")
let year = document.getElementById("year")
let type = document.getElementById("type")
let card_number = document.getElementById("card_number")
let card_name = document.getElementById("card_name")
let card_year = document.getElementById("card_year")
let card_month = document.getElementById("card_month")

number.addEventListener("keyup" , setNumber)
name.addEventListener("keyup" , setName)
date.addEventListener("keyup" , setDate)
year.addEventListener("keyup" , setYear)

function discover(dia){
    if(dia.includes("54321")){
        type.innerHTML = "MasterCard"
    }
    else if(dia.includes("89273")){
        type.innerHTML = "Visa"
    }
    else{
        type.innerHTML = "Discover"
    }
}
function setNumber(x){
    x.preventDefault
    if(isNum(number.value)){
        card_number.innerHTML = number.value
    }
    else{
        alert("error")
    }
    discover(number.value)
}