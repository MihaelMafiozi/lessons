
ChangeButton.addEventListener("click", () =>(
    console.log("text")))

let Theme = changeTheme()
if(Theme == 0){
    Document.body.style.backgroundColor = "rgb(23, 25, 313)"
    document.body.style.color = "white"
    ChangeButton.style.backgroundColor = "white"
    ChangeButton.style.color = "black"
}
else{
    Document.body.style.backgroundColor = "white"
    ChangeButton.style.backgroundColor = "black"
    ChangeButton.style.color = "white"
}
