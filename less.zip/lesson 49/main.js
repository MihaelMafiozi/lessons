let a = document.getElementById("text5")
//     b = a.innerHTML;
// a.innerHTML = "здесь был параграф номер 3"
// b = b + "А"
// alert(b)
// a.innerHTML = "миша готов"
// console.log(a.innerHTML)
// let l = document.getElementsByClassName("")
// console.log(l)
a.setAttribute("class", "n")
